const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const User = require('./models/User');
const groupRoutes = require('./routes/group'); // 그룹 라우트 추가

const app = express();
app.use(cors());
app.use(express.json());

mongoose.connect('mongodb://localhost:27017/studygroup', { useNewUrlParser: true, useUnifiedTopology: true })
  .then(() => console.log('MongoDB에 연결되었습니다.'))
  .catch(err => console.log(err));

// 사용자 회원가입
app.post('/api/register', async (req, res) => {
  const { username, password, mbti, gender } = req.body;
  try {
    const existingUser = await User.findOne({ username });
    if (existingUser) {
      return res.status(400).json({ message: '이미 존재하는 사용자입니다.' });
    }
    const hashedPassword = await bcrypt.hash(password, 10);
    const newUser = new User({ username, password: hashedPassword, mbti, gender });
    await newUser.save();
    const token = jwt.sign({ userId: newUser._id }, 'your_jwt_secret');
    res.status(201).json({ message: '사용자가 성공적으로 등록되었습니다.', userId: newUser._id, token });
  } catch (err) {
    res.status(500).json({ message: '서버 오류' });
  }
});

// 사용자 로그인
app.post('/api/login', async (req, res) => {
  const { username, password } = req.body;
  try {
    const user = await User.findOne({ username });
    if (!user) {
      return res.status(400).json({ message: '잘못된 자격 증명입니다.' });
    }
    const isMatch = await bcrypt.compare(password, user.password);
    if (!isMatch) {
      return res.status(400).json({ message: '잘못된 자격 증명입니다.' });
    }
    const token = jwt.sign({ userId: user._id }, 'your_jwt_secret');
    res.status(200).json({ message: '로그인 성공', userId: user._id, token });
  } catch (err) {
    res.status(500).json({ message: '서버 오류' });
  }
});

// 그룹 라우트 사용
app.use('/api/groups', groupRoutes);

const PORT = process.env.PORT || 5000;
app.listen(PORT, () => {
  console.log(`서버가 ${PORT}번 포트에서 실행 중입니다.`);
});
