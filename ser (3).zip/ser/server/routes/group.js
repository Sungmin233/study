const express = require('express');
const router = express.Router();
const Group = require('../models/Group');
const User = require('../models/User'); // User 모델 추가
const authMiddleware = require('../middleware/auth');

// 그룹 생성
router.post('/create', authMiddleware, async (req, res) => {
  const { name, userId } = req.body;
  try {
    const group = new Group({ name, createdBy: userId, members: [userId] });
    await group.save();

    // 사용자의 groups 필드에 새 그룹 추가
    const user = await User.findById(userId);
    user.groups.push(group._id);
    await user.save();

    res.status(201).json(group);
  } catch (err) {
    res.status(500).json({ message: '서버 오류', error: err.message });
  }
});

// 그룹 목록 검색
router.get('/search', authMiddleware, async (req, res) => {
  const { searchTerm } = req.query;
  try {
    const groups = await Group.find({ name: { $regex: searchTerm, $options: 'i' } });
    res.status(200).json(groups);
  } catch (err) {
    res.status(500).json({ message: '서버 오류', error: err.message });
  }
});

// 그룹 가입
router.post('/:id/join', authMiddleware, async (req, res) => {
  const { id } = req.params;
  const { userId } = req.body;
  try {
    const group = await Group.findById(id);
    if (!group) {
      return res.status(404).json({ message: '그룹을 찾을 수 없습니다.' });
    }
    if (!group.members.includes(userId)) {
      group.members.push(userId);
      await group.save();

      // 사용자의 groups 필드에 그룹 추가
      const user = await User.findById(userId);
      user.groups.push(group._id);
      await user.save();
    }
    res.status(200).json(group);
  } catch (err) {
    res.status(500).json({ message: '서버 오류', error: err.message });
  }
});

// 그룹 탈퇴
router.post('/:id/leave', authMiddleware, async (req, res) => {
  const { id } = req.params;
  const { userId } = req.body;
  try {
    const group = await Group.findById(id);
    if (!group) {
      return res.status(404).json({ message: '그룹을 찾을 수 없습니다.' });
    }
    group.members = group.members.filter(memberId => memberId.toString() !== userId);
    await group.save();

    // 사용자의 groups 필드에서 그룹 제거
    const user = await User.findById(userId);
    user.groups = user.groups.filter(groupId => groupId.toString() !== id);
    await user.save();

    res.status(200).json(group);
  } catch (err) {
    res.status(500).json({ message: '서버 오류', error: err.message });
  }
});

// 그룹 삭제
router.delete('/:id', authMiddleware, async (req, res) => {
  const { id } = req.params;
  try {
    const group = await Group.findById(id);
    if (!group) {
      return res.status(404).json({ message: '그룹을 찾을 수 없습니다.' });
    }
    await Group.findByIdAndDelete(id);

    // 사용자의 groups 필드에서 그룹 제거
    await User.updateMany({ groups: id }, { $pull: { groups: id } });

    res.status(200).json({ message: '그룹이 삭제되었습니다.' });
  } catch (err) {
    res.status(500).json({ message: '서버 오류', error: err.message });
  }
});

// 사용자 ID를 기반으로 사용자가 가입한 그룹 가져오기
router.get('/user/:userId', authMiddleware, async (req, res) => {
  const { userId } = req.params;
  try {
    const user = await User.findById(userId).populate('groups');
    if (!user) {
      return res.status(404).json({ message: '사용자를 찾을 수 없습니다.' });
    }
    res.status(200).json(user.groups);
  } catch (err) {
    res.status(500).json({ message: '서버 오류', error: err.message });
  }
});

router.get('/', authMiddleware, async (req, res) => {
  try {
    const groups = await Group.find();
    res.status(200).json(groups);
  } catch (err) {
    res.status(500).json({ message: '서버 오류', error: err.message });
  }
});

// 사용자 ID를 기반으로 사용자가 만든 그룹 가져오기
router.get('/user/:userId/created', authMiddleware, async (req, res) => {
  const { userId } = req.params;
  try {
    const groups = await Group.find({ createdBy: userId });
    res.status(200).json(groups);
  } catch (err) {
    res.status(500).json({ message: '서버 오류', error: err.message });
  }
});

router.get('/:id', authMiddleware, async (req, res) => {
  const { id } = req.params;
  try {
    const group = await Group.findById(id).populate('members', 'username');
    if (!group) {
      return res.status(404).json({ message: '그룹을 찾을 수 없습니다.' });
    }
    res.status(200).json(group);
  } catch (err) {
    res.status(500).json({ message: '서버 오류', error: err.message });
  }
});

module.exports = router;
